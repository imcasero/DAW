Class Mates {
	public static int mcd(int a , int b){
		return xx
	}
}
public class PruebaMates{
	public static void main(String[] args) {
		//pedir dos numeros al usuario

		//llamar a metos mcd
		int resul =mates.mcd(120, 45);
		// si queremos con obejots
		//Mates myObjMat = new mates();
		//int resul = MyObjMat.mcd(120 , 45);


		//imprimor al maximo comun divisor de los dos puntos
		System.out.println(resul);
	}
}