import java.util.Scanner;
class Jugador{
	String nombre;
	int intentos;
	int barcos;

	public jugador(String nombre){
		this.nombre = nombre;
		intentos = 20;
		barcos = 3;
	}

	public void posicion(){
		
	}

}

public class Barcos{
	public static void main(String[] args) {
		Scanner rc1 = new Scanner(System.in);
		System.out.println("introduzca su nombre jugador 1:");
		String player1 = rc1.nextString();
		Scanner rc2 = new Scanner(System.in);
		System.out.println("Introduzca su nombre jugador 2:");
		String player2 = rc2.nextString();



		
	}
}