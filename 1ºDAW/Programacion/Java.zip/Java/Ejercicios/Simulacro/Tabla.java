public class Tabla{
	public static void main(String[] args) {
		
		for (int i = 0 ; i < 11 ; i++ ) {
			for (int j = 1 ; j < 11 ; j++ ) {
				int resul = i + j;
				System.out.println("Al multiplicar " + i + " por "+ j + " el resultado es " + resul );
				System.out.println("----------------------------------------------------------------");
			}
				System.out.println("================================================================");
		}

	}
}