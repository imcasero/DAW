public class Ej5 {

    public static void main(String[] arg) {
        int j = 1;
        while (j < 11) {
            System.out.println( j );
            j++;
        }
    }
}