public class Ej4 {
    public static void main(String[] args) {
    int i=7 ;

    int resto;

    resto = i % 2;

    System.out.println( resto );

    if (i > 0) {
        System.out.println("Positivo");
    } else {
        System.out.println("Negativo");
    };

    if (resto == 0) {
        System.out.println("Par");
    } else {
        System.out.println("inpar");
    };
}
};
