public class Hipotenusa{
	public static void main(String[] args) {
		int cat1 = 7;
		int cat2 = 15;

		double raiz = (cat1+cat1)+(cat2+cat2);

		double hip = Math.sqrt(raiz);
		System.out.println("La hipotenusa es: " + hip);
	}
}