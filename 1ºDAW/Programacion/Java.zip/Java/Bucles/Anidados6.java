import java.util.Scanner;
public class anidados6{
	public static void main(String[] args) {
		
			//1
			//12
			//123
			//1234
			//12345
			//123456
			//1234567
			//12345678
			//123456789

		
			
		

			for (int lin = 1; lin < 10 ; lin++ ) {
					System.out.println();
					for (int num = 1; num <= lin ; num++ ) {
						System.out.print(num);
					}
				
			}
	}
}