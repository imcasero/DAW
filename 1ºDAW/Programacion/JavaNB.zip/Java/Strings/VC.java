/*Realizar un programa que lea frases por consola hasta que el ususaario introduzca una frase vacia  y que antes de terminar imprima cuantas vocales y cunatas consonantes habia en el texto y el cociente entre ambas.
NOTA:codificar los metodos es vocal y es consonante para detectar estas*/
public class VC{
	public static void main(String[] args) {
		
	}
}