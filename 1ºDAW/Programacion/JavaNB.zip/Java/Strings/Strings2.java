/*
0 si son iguales 
menor que 0 si es menor
mayor que 0 si es mayor
*/

public class Strings2{


	


	public static void main(String[] args) {

		for (int i = 0; i < ; i++ ) {
			
		
		Scanner rc = new Scanner(System.in);
		System.out.println("Introduzca una cadena");
		String cad = 
		}
	}
}