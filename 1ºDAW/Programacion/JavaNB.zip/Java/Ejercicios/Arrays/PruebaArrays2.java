/* ARRAYS  II
  


*/
import java.util.Scanner;


public class PruebaArrays2 {
	
    public static void main(String [] args) {
        

		
		
		Scanner lector = new Scanner(System.in);
		
		
	}
}



/* 
   Ejercicio 1:
      Codifica un método estático denominado buscaNumero que recibe como parámetro un array de enteros y un valor para buscar dentro del array. El método devuelve el índice donde se guarda el valor buscado o -1 si no se encuentra.
	 
   Ejercicio 2: 
      Codifica el método imprimeArrayEnteros que recibe un array de números enteros y los imprime por pantalla,
      en una línea, separado por comas.
   
   Ejercicio 3: 
       Codifica el método estático doblaValores que recibe un array de enteros y multiplica por 2 cada valor del array.
	   Realiza pruebas imprimiendo el array tras modificarlo.
	   
   Ejercicio 4:
       Codifica un método estático denominado rellenaRandArray que recibe como parámetro un array de enteros, un valor mínimo y uno máximo (rango) y rellena el array con número aleatorios en ese intervalo.
	   
      
*/