public class Ejercicios{
	public static float sumaTres(float x , float y , float z){
		float sum = x + y + z;

		return sum;
	}
	public static void printWarring(int x){
		System.out.println("El codigo de error es : " + cod);
	}
	public static String getWarring(int x){
		return w;
	}
	public static float hipotenusa(float c1, float c2){
		return h;
	}
	public static int mediaIntervalo(int x, int y){
		return media;
	}
	public static int[] maximo(int[]){
		
	} 

} 