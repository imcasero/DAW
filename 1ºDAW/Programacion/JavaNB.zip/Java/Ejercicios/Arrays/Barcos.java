import java.util.Scanner;
public class Barcos{

	public Reglas{
		System.out.println("Reglas: cada jugador tendra tres barcos(Lancha , submarino , portaaviones)");
		System.out.println("Lancha(1) Submarino(2) Portaaviones(4)");
		System.out.println("Se debera indicar la primera casilla del cuadro 7x7 donde quiera colocar");
		System.out.println("los barcos , ademas la forma, es decir horizontal(derecha) o vertical(Abajo)");
		System.out.pritnln("Ganara el que derribe antes los barcos");
		System.out.println("Buena suerte jugadores");
	}

	public static void main(String[] args) {
			Reglas;


		Scanner sc1Ax = new Scanner(System.in); // para lancha
		Scanner sc1Ay = new Scanner(System.in);
		Scanner sc2Ax = new Scanner(System.in); // para submarino
		Scanner sc2Ay = new Scanner(System.in);
		Scanner sc3Ax = new Scanner(System.in); // para portaaviones
		Scanner sc3Ay = new Scanner(System.in);

		int[][] tablero1 = new int[7][7];

		Scanner sc1Bx = new Scanner(System.in); // para lancha
		Scanner sc1By = new Scanner(System.in);
		Scanner sc2Bx = new Scanner(System.in); // para submarino
		Scanner sc2By = new Scanner(System.in);
		Scanner sc3Bx = new Scanner(System.in); // para portaaviones
		Scanner sc3By = new Scanner(System.in);

		int[][] tablero2 = new int[7][7];

	}
}