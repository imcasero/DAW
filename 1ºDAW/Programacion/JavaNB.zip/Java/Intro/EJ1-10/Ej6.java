public class Ej6 {

    public static void main(String[] arg) {
        int i = 1;

        do {
            System.out.println( i );
            i++;
        } while (i < 11);
    }
}