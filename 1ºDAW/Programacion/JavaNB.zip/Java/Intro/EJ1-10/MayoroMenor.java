public class MayoroMenor {
    public static void main(String[] args) {
        int i=1;
        int j=2;

            if (i > j) {
                System.out.println(" i es mayor que j ");
            } else {
                System.out.println(" j es mayor que i ");
            }
      }
}