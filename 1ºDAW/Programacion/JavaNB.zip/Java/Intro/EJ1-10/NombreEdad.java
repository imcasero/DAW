public class NombreEdad {
  public static void main(String[] args) {
    
    int edad=20;
    
    System.out.println("Me llamo Diego");
    System.out.println( "Mi edad es :" + edad);
  }
}
