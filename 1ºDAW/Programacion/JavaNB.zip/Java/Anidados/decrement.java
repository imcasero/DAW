import java.util.Scanner;
public class decrement{
	public static void main(String[] args) {
		// ****
		// ***
		// **
		// *

		Scanner rc = new Scanner(System.in);
		int x = rc.nextInt();
for (int j = x; j > 0 ; j-- ) {

	for (int i = j; i > 0 ; i-- ) {
			System.out.print("*");	//**** *** ** *
		}
		System.out.println(" ");
	
}
		
	}
}